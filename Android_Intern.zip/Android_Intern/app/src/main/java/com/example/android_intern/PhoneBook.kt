package com.example.android_intern

data class PhoneBook(
    val name: String,
    val phone: String,
    val type: String
)